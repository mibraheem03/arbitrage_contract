
const { ethers } = require('ethers');

const NODE = ""
